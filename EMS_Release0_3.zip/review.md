# Refaktoroinnin Katselmointi (2026-06-10)

## Tiivistelma
- Laaja refaktorointi on paapiirteissaan yhtenainen: testit menevat lapi (`94 passed, 2 xfailed`).
- Legacy-surplus-avaimen (`surplus_ev_active`) migration cleanup on toteutettu Phase 1 + Phase 2 -tasolla (koodi/testit/dokumentit paivitetty).
- `nz_battery_floor_default_w` on kytketty NET_ZERO-laskentaan ja varmistettu regressiotestilla.
- Unsupported combo -fallbackille on lisatty eksplisiittinen varoitusdiagnostiikka, joten fallback ei enaa ole hiljainen.

## Kriittiset havainnot (release-riskit)

### 1) Konfiguraatioarvo luetaan mutta ei vaikuta laskentaan (STATUS: RESOLVED)
- Vaikutus: Kayttaja voi luulla saativansa akun default floor -arvoa (`input_number.ems_nz_battery_floor_default_w`), mutta tuotantologiikka ohittaa sen NET_ZERO-peruspolussa.
- Naytto:
  - `ems_policy_engine.py:33` lukee `nz_battery_floor_default_w`
  - Toteutettu: `modules/ems_core/net_zero/engine.py:125` kayttaa nyt `cfg.nz_battery_floor_default_w`-arvoa.
- Validointi:
  - Uusi regressiotesti: `tests/unit/test_engine.py` (`test_engine_net_zero_uses_configurable_default_battery_floor`)
  - Testitulos toteutuksen jalkeen: `94 passed, 2 xfailed`

### 2) Refaktoroinnin migration-alueet edelleen XFAIL-tilassa
- Vaikutus: kaksi skenaariota on tietoisesti ei-blokkaavia (`xfail`), eli osa V2-prioriteettisemantiikasta on edelleen keskenerainen.
- Naytto:
  - `tests/e2e_entity/test_ev_primary_battery_dispatch_journey_e2e.py:16`
  - `tests/e2e_entity/test_net_zero_ev_primary_charge_mode_spec.py:16`
- Riski release-paattoksessa: jos julkaisu odottaa EV-primary V2-kayttaytymisen olevan tuotantovalmis, testitila ei viela sita takaa.
- Suositus: release noteen eksplisiittinen rajaus, mita EV-primary V2-polusta pidetaan "known limitation"-tilassa.

## Merkittavat legacy-janteet (ei valttamatta blocker, mutta huomioitava)

### 3) Legacy `surplus_ev_active` (STATUS: RESOLVED)
- Toteutus:
  - Poistettu entity mapista: `modules/ems_adapter/entity_map.py`
  - Poistettu E2E-harnessista ja migration-skenaarioista
  - Dokumentit paivitetty `surplus_adjustable_active`-nimistoon
- Johtopaatos: aiempi semanttinen sekaannusriski ei enaa ole aktiivinen release blocker.

### 4) E2E migration-artefaktit (STATUS: RESOLVED for surplus-key naming)
- Toteutus: sekakaytto (`surplus_ev_active` + `surplus_adjustable_active`) poistettu aktiivisista E2E-polkujen odotuksista.
- Jalkiriski: pitkat skenaariot kannattaa edelleen refaktoroida pienempiin osiin luettavuuden vuoksi, mutta naming-migration itsessaan on valmis.

### 5) Hiljainen fallback ei-tuettuun kombinaatioon voi peittaa konfiguraatiovirheen (STATUS: MITIGATED)
- Toteutus: moottorin trace-attribuutteihin lisatty fallback-varoitusdiagnostiikka.
- Naytto:
  - `modules/ems_core/net_zero/engine.py` julkaisee nyt attribuutit:
    - `primary_surplus_combo_fallback_active`
    - `primary_surplus_combo_warning`
  - `primary_surplus_combo_reason='fallback_to_cross_combo'` on edelleen mukana syykenttana.
- Validointi:
  - Uusi unit-testi: `tests/unit/test_engine.py` (`test_engine_same_target_combo_emits_fallback_warning_attrs`)
- Johtopaatos: fallback-kayttaytyminen on edelleen turvallinen, mutta ei enaa hiljainen; operaattori havaitsee konfiguraatiovirheen diagnostiikasta.

## Testi- ja validointitila
- Ajettu: `pytest -q`
- Tulos: `94 passed, 2 xfailed in 3.41s`
- Johtopaatos: peruslaatu on hyva; aktiiviset release-riskit keskittyvat nyt XFAIL-merkattuihin EV-primary V2 -skenaarioihin.

## Markdown-dokumenttien paivitystarve

### Kokonaisarvio
- Markdown-tiedostoja: 11
- Selvasti paivitettavia: 0 kohdassa `surplus_ev_active` (Phase 1 toteutettu)
- Luonne: tehty paivitys oli paosin terminologia-/entiteettinimien harmonisointia.

### Korkea prioriteetti
1. (Resolved) `ems_step_model.md`, `README.md`, `arkkitehtuuri.md`, `operointi.md`
- Nimistopaivitykset tehty `surplus_adjustable_active`-muotoon.

### Keskitaso
1. `testausautomaatio.md`
- Viittaa `haeo_horizon.py`-tiedostoon ilman nykyista moduulipolkua (`modules/ems_core/integrations/haeo_horizon.py`), kannattaa tarkentaa jotta dokumentti pysyy refaktoroinnin rakenteen kanssa linjassa.
- Naytto: `testausautomaatio.md:172`.

## Release-paatoksen muistilista
1. `surplus_ev_active` migration on toteutettu loppuun (Phase 2), ei enaa avoin paatoskohta.
2. `nz_battery_floor_default_w` on kytketty kayttoon, ei enaa avoin release-paatoskohta.
3. Hyvaksytaanko julkaisu kahden `xfail`-skenaarion kanssa (EV-primary V2 osittain kesken)?
4. Tarvitaanko erillinen migration note Home Assistant -dashboardeille, jos ne ovat seuranneet vanhaa entitya?
