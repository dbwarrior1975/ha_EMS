# Adjustable Surplus Load Spec (V2)

## 1. Tavoite

Määritellään uusi yhtenäinen malli surplus-priorisoinnille, jossa on yksi abstrahoitu säädettävä latauskohde ("adjustable surplus load").

Tavoite:
- poistaa EV/BATTERY-erikoishaarat surplus-dispatchista
- tehdä prioriteettisemantiikasta käyttäjälle johdonmukainen

## 2. Muutos aiempaan toteutukseen

Tama luku kuvaa erot aiempaan (refactoroimaton/legacy) kayttaytymiseen.

Ennen:
- EV/BATTERY-kombinaatioissa kayttaytyminen oli osin dispatch-latch -lahtoista.
- EV:n pysaytys matalassa PV:ssa ei ollut eksplisiittisesti vaiheistettu anti-flap -prosessina kaikissa ristiinkytkennan poluissa.
- Diagnostiikka ei tehnyt aina nakyvaksti eroa "release 0 A" vs "hard_off 0 A" paatosten syylle.

Nyt:
- EV-primary-polku arvioidaan jatkuvasti ja anti-flap -polku on vaiheistettu: restore_min ennen mahdollista hard_off-aktivointia.
- Matalan PV:n battery -> EV loop -riski on eksplisiittinen paatossignaali, joka estaa EV burn -tilaa riskitilanteessa ilman force-ohitusta.
- Trace kertoo paatoksen syyt tarkemmin (mm. hard_off-tila, low-PV-syklit, loop-riski, floor-syy).

### 2.1 Termit ja nimeaminen (normatiivinen)

Tassa dokumentissa kaytetaan konfiguraatio- ja mittaustasoilla ensisijaisesti EMS entity_map -avaimia (esim. `ev_min_current_a`), ei Home Assistant entity_id -arvoja.

Peruskasitteet:
- RPC = `required_power_consumption_kw`
- RPNZ = `rpnz_w`
- PV = `pv_power_kw`


## 3. Uusi käsitemalli

Uusi dispatch-malli käyttää kohteita:
1. `ADJUSTABLE`
2. `RELAY1`
3. `RELAY2`

`ADJUSTABLE` on looginen kohde, jonka fyysinen toteutus valitaan konfiguraatiolla:
- EV-laturi
- kotiakku

## 4. Konfiguraatio (entiteetit)

Pakolliset:
- `adjustable_surplus_load`
- `adjustable_surplus_load_priority`
- `adjustable_primary_load`

`adjustable_surplus_load` arvot:
- `EV_CHARGER`
- `HOME_BATTERY`

`adjustable_primary_load` arvot:
- `EV_CHARGER`
- `HOME_BATTERY`

Tuetut kombinaatiot V2:ssa:
1. `adjustable_primary_load = HOME_BATTERY` ja `adjustable_surplus_load = EV_CHARGER`
2. `adjustable_primary_load = EV_CHARGER` ja `adjustable_surplus_load = HOME_BATTERY`

Ei-tuetut kombinaatiot V2:ssa:
- `adjustable_primary_load = HOME_BATTERY` ja `adjustable_surplus_load = HOME_BATTERY`
- `adjustable_primary_load = EV_CHARGER` ja `adjustable_surplus_load = EV_CHARGER`



## 5. Semantiikka

### 5.1 Aktivointi

- `next_target` valitaan vain eligible-kohteista.
- Konfiguraation prioteetit ohjaavat järjestystä

### 5.2 Release

- Kun `rpnz_w <= 0` ja aktiivisia kohteita on, release tehdään matalimman prioriteetin aktiivisesta kohteesta.
- Joten jos aktiivisena on vain `ADJUSTABLE`, release osuu siihen riippumatta siitä, onko taustalla EV vai akku.

### 5.3 Priority

- Priority on globaali ja suora:
  - suurempi numero = korkeampi prioriteetti
- Sama sääntö kaikissa moodissa.
- Priority ei koskaan vaihda merkitystä moodin mukaan.

### 5.4 ADJUSTABLE-tehon muodostus

- Aktivointi ja release pysyvät aina dispatch-päätöksinä (`ACTIVATE_ADJUSTABLE` / `RELEASE_ADJUSTABLE`).
- `adjustable_surplus_load` määrittää vain, mikä fyysinen kohde on dispatchin `ADJUSTABLE`-target.
- `ADJUSTABLE`-aktivointi ei yksinään lukitse battery setpointia kiinteään `max_solar_charge_w`-tasoon.
- Sekä `EV_CHARGER` että `HOME_BATTERY` käyttävät oletuksena samaa RPNZ-pohjaista jatkuvaa tehonsäätöä (`rpnz_w`); dispatch ohjaa targetin aktiivisuutta, ei poista jatkuvan säätimen evaluointia.

Lisasaanto (EV-primary + HOME_BATTERY adjustable):
- Kun `surplus_adjustable_active = True` ja `rpnz_w >= 0`, battery-target asetetaan `adjustable_surplus_activation`-arvosta muodostettuun clampiin:
  - `activation_clamped_w = clamp(adjustable_surplus_activation, 0, max_solar_charge_w)`
- Kun aktivointigaten ehto on voimassa (ei viela aktiivinen, RPC alle activation-kynnyksen), gate koskee vain latausaluetta (positiiviset battery-targetit).
- Normatiivinen rajaus:
  - Jos `current_sp_w >= 0` ja `candidate_sp_w >= 0`, battery-targetia ei nosteta yli nykyisen setpointin:
    - `final_sp_w = min(candidate_sp_w, current_sp_w)` (`activation_gate_hold`)
  - Jos jompikumpi arvoista on negatiivinen, gate ei saa estaa normaalia RPNZ-saantimen dynamiikkaa.
  - Erityisesti siirtyma `-2000 -> -500 -> 0` on sallittu, kun jatkuva saadin muuten tuottaa taman kehityksen.
  - Gate ei saa lukita purkupuolen arvoja vain siksi, etta `candidate_sp_w > current_sp_w` negatiivisella alueella.

### 5.5 Ensisijainen säätökanava (`adjustable_primary_load`)

- `adjustable_primary_load` määrittää, mikä säädettävä kohde on NET_ZERO-tehosäätimen ensisijainen ohjauskanava.
- V2:ssa primary ja surplus ovat aina eri kohteet (ristiinkytkentä).
- Kun primary on `HOME_BATTERY`, battery targetia arvioidaan jatkuvasti RPNZ-säätimellä jokaisessa syklissä ja dispatchin `ADJUSTABLE`-target on EV_CHARGER.
- Kun primary on `EV_CHARGER`, EV-targetia arvioidaan jatkuvasti EV-ohjaussäännöillä ja dispatchin `ADJUSTABLE`-target on HOME_BATTERY.
- `adjustable_primary_load` ei muuta dispatch-prioriteetin järjestystä eikä release-sääntöjä.

#### 5.5.1 Normatiivinen laskentatapa (ensisijainen kanava)

Tämä kohta määrittää yksiselitteisen laskentatavan, johon toteutus ja testit saavat nojata.

Syklikohtainen järjestys:
1. Valitse primary-kanava `adjustable_primary_load` arvosta.
2. Laske yhteinen primary power envelope (`primary_power_envelope_w`) jokaisessa syklissä.
3. Muunna envelope primary-kanavan ohjausarvoksi (battery W tai EV A).
4. Sovella guard/strict-limit -clampit.
5. Sovella dispatch-tilasiirtymät (`ACTIVATE_*` / `RELEASE_*`) ilman, että ne poistavat primary-kanavan jatkuvaa evaluointia.

Power envelope (normatiivinen perusmalli):
- Envelope lasketaan samalla dynaamisella periaatteella riippumatta siitä, onko primary EV vai battery.
- Suositeltu laskenta per sykli:
  - `error_w = rpnz_w - grid_power_w`
  - `delta_w = error_w / 2`
  - jos `abs(delta_w) < deadband_w` -> pidä edellinen envelope
  - muuten:
    - `step_w = round(delta_w / 100) * 100`
    - `step_w = clamp(step_w, -ramp_max_w, ramp_max_w)`
    - `envelope_w = prev_envelope_w + step_w`
- Envelope clampataan kanavakohtaisiin rajoihin ennen lopullista mappausta.

Kun `adjustable_primary_load = HOME_BATTERY`:
- `policy_battery_target_w` johdetaan suoraan envelope-arvosta (`policy_battery_target_w = envelope_w`) battery-rajoja noudattaen.
- `policy_ev_current_a` määräytyy EV-politiikasta, mutta ei ole primary-laskennan ohjaava suure.

Kun `adjustable_primary_load = EV_CHARGER`:
- `policy_ev_current_a` johdetaan envelope-arvosta EV-portaiden mukaan.
- Portaiden koko tulee asetuksesta `ev_current_step_a`.
- Minimi- ja maksimirajat tulevat asetuksista `ev_min_current_a` ja `ev_max_current_a`.
- Suositeltu normatiivinen muoto:
  - `raw_a = round(max(envelope_w, 0) / (ev_charger_phases * 230))`
  - jos `raw_a <= 0` -> `policy_ev_current_a = 0`
  - muuten kvantisointi minimin yläpuolella step-arvolla:
    - `policy_ev_current_a = min(max_a, max(min_a, min_a + floor((raw_a - min_a) / step_a) * step_a))`
  - missä `step_a = max(1, ev_current_step_a)`

Lisäsääntö (akku EV-primary tapauksessa):
- EV-primary ei käytä legacy-akuston 100 W oletusflooria, ellei guard/logiikkapoikkeus sitä erikseen vaadi.
- Tavoite on, että EV:n nopea säätö ei lukkiudu akun legacy-minimitasoon.

Lisäsääntö (EV-primary + HOME_BATTERY adjustable, hard_off-vapautus):
- Kombinaatiossa `adjustable_primary_load = EV_CHARGER` ja `adjustable_surplus_load = HOME_BATTERY` hard_off-vapautus ei saa perustua pelkkään ehtoon `rpnz_w > 0`.
- Vapautus sidotaan EV:n minivirran tehovaatimukseen (RPC), PV-kynnykseen ja syklipysyvyyteen:
  - `hard_off_release_rpc_kw = ev_min_current_a * ev_charger_phases * 230 / 1000`
  - `required_power_consumption_kw >= hard_off_release_rpc_kw`
  - `pv_power_kw >= ev_hard_off_pv_threshold_kw`
  - ehto on täyttynyt vähintään `ev_hard_off_release_cycles` peräkkäisen syklin ajan
  - `battery_to_ev_loop_risk = False`
- Suositellut oletukset V2:ssa:
  - `ev_hard_off_release_cycles = 2`
- Jos yllä oleva vapautusehto ei täyty, hard_off-tila säilyy aktiivisena vaikka `rpnz_w` olisi hetkellisesti positiivinen.

Lisäsääntö (yhtenäisyys):
- Samaan syklin tilaan perustuva envelope-laskenta on ensisijainen tapa varmistaa, että HOME_BATTERY- ja EV_CHARGER-primary seuraavat samaa tehodynamiikkaa.
- Kanavien ero on ensisijaisesti output-yksikössä (W vs A) ja EV-portaiden kvantisoinnissa.

### 5.6 Ristiinkytkennän normatiivinen sääntö

- V2:ssa sallitaan vain kaksi kombinaatiota (kohta 4).
- Jos konfiguraatio ei vastaa tuettua kombinaatiota, policy siirtyy turvalliseen fallback-käyttäytymiseen ja trace kertoo syyn.
- Dispatch ohjaa aina vain `ADJUSTABLE`-targetin aktivointia/releaseä; primary-kanava jatkaa jatkuvaa säätöä omilla säännöillään.
- Guard- ja strict-limit -rajoitteet voivat edelleen clampata setpointia.

Tulkintasääntö (normatiivinen):
- Ristiinkytkennässä targetit eivät määräydy yhdellä kaavalla, vaan seuraavalla prioriteettijärjestyksellä:
1. Guard/strict-limit -rajoitteet (turvallisuus)
2. Kombinaation validointi (tuettu/ei-tuettu)
3. Dispatch-tilasiirtymän poikkeushaarat (activate/release/clear)
4. Primary-load-polun ohjaushaarat (EV/BATTERY)
5. Varsinainen jatkuva säädin (RPNZ / EV-sääntö)
- Effective-RPNZ on suositeltu oletus EV-tehon vähennykseen, mutta sitä ei pidetä ainoana sallittuna toteutusmuotona, jos yllä olevat prioriteettisäännöt säilyvät ja hyväksymiskriteerit täyttyvät.

### 5.7 EV HARD_OFF ristiinkytkennässä (normatiivinen)

Tavoite:
- Hyödyntää olemassa oleva HARD_off-konsepti myös V2-rastiinkytkennässä semanttisesti yhtenäisellä tavalla.
- Estää tilanne, jossa EV-lataus jatkuu käytännössä home_batteryn purkuteholla tilanteessa, jossa PV-tuotto on liian pieni tai nolla.

Soveltamisala:
- Tämä sääntö koskee erityisesti kombinaatiota:
  - `adjustable_surplus_load = EV_CHARGER`
  - `adjustable_primary_load = HOME_BATTERY`

Normatiivinen periaate:
1. Kun EV ei ole burn-tilassa ja matalan PV:n ehto jatkuu riittävän pitkään (`ev_hard_off_low_pv_cycles`), policy saa asettaa EV:n HARD_off-tilaan.
2. HARD_off-tilassa writer disabloi EV-latauksen ja pitää virta-asetuksen laiteteknisen minimin mukaisena.
3. HARD_off saa purkautua vasta, kun uudelleenaktivoinnin ehto täyttyy (hystereesi), jotta vältetään on/off-fläppäys.
4. `ev_force_current_a > 0` ohittaa HARD_off-käytöksen (manual floor -semantiikka säilyy).

Normatiivinen suositus (battery -> EV loopin esto):
- Jos `pv_power_kw` on alle `ev_hard_off_pv_threshold_kw` ja battery-target on purkava (`policy_battery_target_w < 0`) usean syklin ajan, EV tulee siirtää HARD_off-tilaan ellei force-current ole aktiivinen.

Diagnostiikka (trace-vaatimus):
- Traceen tulee kirjata vähintään:
  - `ev_policy_mode`
  - `ev_low_pv_cycles`
  - `ev_hard_off_active`
  - `pv_power_kw`
  - `ev_hard_off_pv_threshold_kw`

### 5.8 EV anti-flap progression (restore_min -> hard_off)

Tama kohta tarkentaa hard_off-kayttaytymisen vaiheistuksen.

Normatiivinen periaate:
1. Kun EV burn paattyy, EV saa ensin siirtya `restore_min`-tilaan.
2. EV-primary-polussa `restore_min` voi asettaa policy-currentin arvoon `ev_min_current_a` ennen hard_off-kynnyksen tayttymista.
3. Vasta kun low-PV-persistence ehto tayttyy (`ev_hard_off_low_pv_cycles`), policy saa siirtya `hard_off`-tilaan ja `policy_ev_current_a = 0`.
4. `hard_off`-tilassa writer disabloi laturin ja pitaa current-selectorin hardware-minimissa.

Loop-riskin tarkennus:
- Jos seuraavat ehdot toteutuvat samanaikaisesti:
  - `pv_power_kw < ev_hard_off_pv_threshold_kw`
  - battery on purkava (`current_battery_setpoint_w < 0` tai policy-target purkava)
  - `ev_force_current_a <= 0`
  niin `battery_to_ev_loop_risk` kasitellaan aktiiviseksi ja EV burn estetaan riskin aikana.

Hard_off-vapautuksen tarkennus EV-primary-kombossa:
- Kombinaatiossa (primary=EV_CHARGER, surplus=HOME_BATTERY) hard_off-vapautus tehdään vain yllä kuvatulla EV-minivirtaan sidotulla RPC-kynnyksellä ja hysteresisilla.
- Pelkkä `rpnz_w > 0` ei ole riittävä vapautusehto.
- Jos vapautusehto ei täyty, `ev_policy_mode` pysyy `hard_off`-tilassa.

## 6. Dispatch state -malli

Uudet state-entiteetit:
- `surplus_adjustable_active`
- `surplus_r1_active`
- `surplus_r2_active`



## 7. Policy/Writer-rajapinta

Policy tuottaa aina:
- `surplus_dispatch_decision` (ACTIVATE/RELEASE/CLEAR_ALL)
- `surplus_next_target`
- `surplus_release_candidate`

Writer päättää `ADJUSTABLE`-kohteen fyysisen toiminnon `adjustable_surplus_load`-valinnan mukaan:
- `EV_CHARGER`: ohjaa EV-currentia
- `HOME_BATTERY`: ohjaa battery setpointia

Lisäksi policy käyttää `adjustable_primary_load`-arvoa ensisijaisen tehosäätökanavan valintaan:
- `EV_CHARGER`: EV on ensisijainen säädettävä kuorma
- `HOME_BATTERY`: battery on ensisijainen säädettävä kuorma

Policy validoi lisäksi, että primary/surplus-kombinaatio on tuettu (kohta 4).

## 8. Trace-vaatimukset

`policy_decision_trace` sisältää vähintään:
- `surplus_primary_target` (aina `ADJUSTABLE` V2:ssa)
- `surplus_next_target`
- `surplus_release_candidate`
- `surplus_dispatch_decision`
- `surplus_explanation`
- `adjustable_surplus_load`
- `adjustable_primary_load`
- `primary_surplus_combo_valid`
- `primary_surplus_combo_reason`
- `adjustable_surplus_load_priority`
- `active_stack`

Suositeltu minimilaajennus (EV-primary/HARD_off diagnostiikka):
- `ev_policy_mode`
- `ev_low_pv_cycles`
- `ev_hard_off_active`
- `ev_hard_off_release_ready_cycles`
- `ev_hard_off_release_cycles_required`
- `ev_hard_off_release_rpc_kw`
- `pv_power_kw`
- `ev_hard_off_pv_threshold_kw`
- `battery_to_ev_loop_risk`
- `ev_primary_burn_active`
- `ev_surplus_burn_active`
- `battery_min_floor_w`
- `battery_min_floor_reason`
- `primary_power_envelope_w`



## 10. Hyväksymiskriteerit

1. Priority-semanttiikka on identtinen riippumatta valitusta adjustable-kuormasta.
2. `ADJUSTABLE`-target toimii sekä EV- että battery-valinnalla ilman eri dispatch-haaraa.
3. Release-käytös on deterministinen ja trace selittää päätökset.
4. Vain kaksi kombinaatiota ovat tuettuja: (primary=HOME_BATTERY, surplus=EV_CHARGER) ja (primary=EV_CHARGER, surplus=HOME_BATTERY).
5. Saman kohteen kombinaatiot (EV/EV ja BATTERY/BATTERY) tunnistetaan ei-tuetuiksi ja käsitellään deterministisellä fallbackilla.
6. `adjustable_surplus_load` vaikuttaa vain ADJUSTABLE dispatch-targetin valintaan, ei suoraan primary-tehosäätimen valintaan.
7. `adjustable_primary_load` vaikuttaa vain ensisijaisen tehosäätökanavan valintaan, ei dispatch-prioriteettijärjestykseen.
8. `rpnz_w` tilanvaihdot näkyvät ensisijaisen säätökanavan ohjauksessa säätimen sääntöjen mukaisesti.
9. Trace raportoi aina kombinaation validiuden ja fallback-syyn.
10. Vanha testiportfolio saadaan vihreäksi tai korvataan V2-vastineilla dokumentoidusti.
11. Primary-ohjaus perustuu yhteiseen power envelope -laskentaan riippumatta primary-kanavasta; kanavien erot ovat vain rajoissa ja output-mappauksessa.
12. Kombinaatiossa (primary=HOME_BATTERY, surplus=EV_CHARGER) HARD_off estää tilanteen, jossa EV-lataus jatkuu pitkittyneesti battery-purkuteholla matalan PV:n aikana ilman force-current -ohitusta.
13. EV anti-flap progression toteutuu: ennen hard_off-aktivointia EV voi kayda `restore_min`-vaiheen kautta; hard_off-aktivoinnin jalkeen policy asettaa EV:n 0 A:han.
14. Trace tekee eron release- ja hard_off-polkujen valilla siten, etta syy voidaan todentaa ilman writer-lokien tulkinnanvaraa.
15. Aktivointigate (`activation_gate_hold`) rajoittaa vain positiivisen latausalueen ylospain nostoa ennen aktivointia; se ei saa estaa normaalia negatiiviselta puolelta kohti nollaa tapahtuvaa palautumista (esim. `-2000 -> -500 -> 0`).
16. Kombinaatiossa (primary=EV_CHARGER, surplus=HOME_BATTERY) hard_off ei purkaudu pelkästä `rpnz_w > 0` -ehdosta, vaan vaatii EV-minivirtaan sidotun RPC-release-kynnyksen (`required_power_consumption_kw`), PV-hysteresisin (`pv_power_kw` vs `ev_hard_off_pv_threshold_kw`) ja peräkkäisten syklien ehdon.

## 11. Ei-tavoitteet (tässä vaiheessa)

- Ei muuteta guard-mallia.
- Ei muuteta HAEO-integraation peruslogiikkaa.


## 12. Ehdotettu toteutusjärjestys

1. Domain-malli: lisää `ADJUSTABLE` target-tyyppiin.
2. Entity map: lisää V2-entiteetit.
3. Engine: yksi unified target-lista (`ADJUSTABLE`, `RELAY1`, `RELAY2`).
4. Lisää kombinaatiovalidointi (vain 2 tuettua yhdistelmää) policyyn.
5. Dispatch applier: `ACTIVATE_ADJUSTABLE` / `RELEASE_ADJUSTABLE`.
6. Lisää `adjustable_primary_load` entity mapiin ja policyyn.
7. Writer adapter: route ADJUSTABLE target by `adjustable_surplus_load`, primary control by `adjustable_primary_load`.
8. E2E: uudet V2-skenaariot kahdelle tuetulle kombinaatiolle + ei-tuettujen kombinaatioiden fallback.


---

Tämä dokumentti on tarkoitettu seuraavan session toteutusspeksiksi.
