from ems_adapter.ha_adapter import get_attr, get_bool, get_float, get_int, get_str, publish_sensor, set_boolean, set_number
from ems_core.domain.ev_power import ev_min_current_a_from_min_absorb_w, ev_power_w_to_current_a
from ems_core.domain.models import EmsDeviceConfig
from ems_core.domain.capabilities import clamp_target_w_for_capabilities, capability_block_reason


def _load_runtime_entities():
    ent = globals().get('ENT', {})
    try:
        reader = globals().get('read_runtime_entities')
        if reader is None:
            from ems_adapter.runtime_context import read_runtime_entities as reader
        runtime_entities = reader(get_bool, get_float, get_int, get_str)
    except Exception:
        runtime_entities = {}
    if ent:
        merged = dict(ent)
        merged.update(runtime_entities)
        return merged
    return runtime_entities


def _load_core_config():
    reader = globals().get('read_core_config')
    if reader is not None:
        return reader()
    from ems_adapter.runtime_context import read_core_config

    return read_core_config(get_bool, get_float, get_int, get_str)


def _ent(key, fallback, entities=None):
    if entities is not None and key in entities:
        return entities[key]
    ent = globals().get('ENT', {})
    return ent.get(key, fallback)


def _resolve_float_value(value, default=0.0):
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str) and value:
        try:
            return float(value)
        except ValueError:
            return get_float(value, default)
    return float(default)


def _quantize_50w(value):
    return int(round(float(value) / 50.0) * 50)


def _device_policy_by_id(device_id, entities=None):
    get_attr_fn = globals().get('get_attr')
    if get_attr_fn is None:
        return None

    source_entities = (
        _ent('device_policies', 'sensor.ems_device_policies_pyscript', entities),
        _ent('policy_decision_trace', 'sensor.ems_policy_decision_trace_pyscript', entities),
    )
    for source_entity in source_entities:
        policies = get_attr_fn(source_entity, 'device_policies', None)
        if not policies:
            continue
        for policy in policies:
            if isinstance(policy, dict) and policy.get('device_id') == device_id:
                return policy
    return None


def _device_policy_enabled(policy, default=False):
    if policy is None or 'enabled' not in policy:
        return default
    raw = policy.get('enabled')
    if isinstance(raw, bool):
        return raw
    return str(raw).lower() in ('1', 'true', 'on', 'yes')


def _device_policy_target_w(policy, default=0):
    if policy is None or 'target_w' not in policy:
        return default
    return float(policy.get('target_w') or 0)


def _previous_device_state_mode(entities=None):
    get_attr_fn = globals().get('get_attr')
    if get_attr_fn is None:
        return ''

    mode = get_attr_fn(_ent('previous_device_state', 'sensor.ems_previous_device_state', entities), 'mode', '')
    if mode:
        return str(mode)
    return ''


def _capability_device_config_for_id(device_id):
    cfg = _load_core_config()
    device = cfg.device_by_id(device_id) if hasattr(cfg, 'device_by_id') else None
    if device is None:
        return None
    caps = device.capabilities
    policy = device.policy
    return EmsDeviceConfig(
        device_id=str(device.device_id),
        kind=str(device.kind),
        response_kind='continuous' if str(device.kind) == 'BATTERY' else ('selector' if str(device.kind) == 'EV_CHARGER' else 'relay'),
        can_absorb_w=bool(caps.can_absorb_w),
        can_produce_w=bool(caps.can_produce_w),
        min_absorb_w=int(round(float(caps.min_absorb_w))),
        max_absorb_w=int(round(float(caps.max_absorb_w))),
        max_produce_w=int(round(abs(float(caps.max_produce_w or 0)))),
        step_w=max(1, int(round(float(caps.step_w)))),
        priority=int(round(float(policy.priority))),
    )


def _write_battery_actuator(entities=None):
    control = get_str(_ent('control_profile', 'input_select.ems_control_profile', entities), 'AUTOMATIC')

    if control == 'MANUAL':
        return {
            'target': 'victron',
            'action': 'skip',
            'reason': 'manual_skip',
            'written': False,
        }

    device_policy = _device_policy_by_id('HOME_BATTERY', entities)
    if device_policy is None:
        return {
            'target': 'victron',
            'action': 'skip',
            'reason': 'missing_device_policy',
            'written': False,
            'policy_source': 'missing_device_policy',
        }

    policy_source = 'device_policy'
    write_enabled = _device_policy_enabled(device_policy)
    if not write_enabled:
        return {
            'target': 'victron',
            'action': 'skip',
            'reason': 'policy_write_disabled',
            'written': False,
            'policy_source': policy_source,
        }

    target_w = _device_policy_target_w(device_policy, default=0)
    capability_cfg = _capability_device_config_for_id('HOME_BATTERY')
    if capability_cfg is None:
        return {
            'target': 'victron',
            'action': 'skip',
            'reason': 'missing_device_config',
            'written': False,
            'policy_source': policy_source,
        }
    capability_reason = capability_block_reason(capability_cfg, target_w)
    target_w = clamp_target_w_for_capabilities(capability_cfg, target_w)
    battery_entity = _ent('actuator_battery_setpoint_w', 'number.victron_mqtt_b827eb48c929_system_0_system_ac_power_set_point', entities)
    current_w = get_float(battery_entity, 0)
    deadband = get_float(_ent('deadband_w', 'input_number.ems_deadband_w', entities), 100)
    ramp = get_float(_ent('ramp_max_w', 'input_number.ems_ramp_max_w', entities), 500)

    delta = target_w - current_w
    if abs(delta) < deadband:
        return {
            'target': 'victron',
            'action': 'skip',
            'reason': 'deadband',
            'written': False,
            'current_w': current_w,
            'target_w': target_w,
            'delta_w': delta,
            'policy_source': policy_source,
            'capability_reason': capability_reason,
        }

    step = max(min(delta, ramp), -ramp)
    new_setpoint = _quantize_50w(current_w + step)
    set_number(battery_entity, new_setpoint)

    return {
        'target': 'victron',
        'action': 'write',
        'reason': capability_reason or ('manual_safe_clamp' if control == 'MANUAL_SAFE' else 'state_changed'),
        'written': True,
        'current_w': current_w,
        'policy_target_w': target_w,
        'written_w': new_setpoint,
        'policy_source': policy_source,
    }


def _write_ev_actuator(device_id='EV_CHARGER', entities=None):
    device_policy = _device_policy_by_id(device_id, entities) if device_id else None
    if device_policy is None:
        return {
            'target': 'ev',
            'action': 'skip',
            'reason': 'missing_device_policy',
            'written': False,
            'policy_source': 'missing_device_policy',
        }

    policy_source = 'device_policy'
    device_entities = (entities or {}).get('devices', {}) or {}
    device_runtime = device_entities.get(device_id, {})
    enabled_entity = device_runtime.get('enabled') or _ent('actuator_ev_enabled', 'switch.charger_control', entities)
    current_entity = device_runtime.get('current_a') or _ent('actuator_ev_current_a', 'number.charger_current_level', entities)
    current_on = get_bool(enabled_entity)
    current_level = get_int(current_entity, 0)
    step_a = get_float(device_runtime.get('current_step_a') or _ent('ev_current_step_a', 'input_number.ems_ev_current_step_a', entities), 4)
    phases = get_float(device_runtime.get('phases') or _ent('ev_charger_phases', 'input_number.ems_ev_charger_phases', entities), 1)
    voltage_v = get_float(device_runtime.get('voltage_v') or _ent('ev_voltage_v', 'input_number.ems_ev_voltage_v', entities), 230)
    ev_policy_mode = str(device_policy.get('mode') or _previous_device_state_mode(entities) or '')
    capability_reason = ''
    target_w = _device_policy_target_w(device_policy, default=0)
    capability_cfg = _capability_device_config_for_id(device_id or 'EV_CHARGER')
    if capability_cfg is None:
        return {
            'target': device_id,
            'action': 'skip',
            'reason': 'missing_device_config',
            'written': False,
            'policy_source': policy_source,
        }
    min_absorb_w = _resolve_float_value(device_runtime.get('min_absorb_w', capability_cfg.min_absorb_w), capability_cfg.min_absorb_w)
    max_absorb_w = _resolve_float_value(device_runtime.get('max_absorb_w', capability_cfg.max_absorb_w), capability_cfg.max_absorb_w)
    derived_min_a = ev_min_current_a_from_min_absorb_w(
        min_absorb_w,
        phases=phases,
        voltage_v=voltage_v,
        current_step_a=step_a,
    )
    if ev_policy_mode == 'skip':
        target_current_a = -1
    else:
        capability_reason = capability_block_reason(capability_cfg, target_w)
        target_w = clamp_target_w_for_capabilities(capability_cfg, target_w)
        if capability_reason:
            ev_policy_mode = 'hard_off'
        target_current_a = 0
        if target_w > 0 and ev_policy_mode != 'hard_off':
            target_current_a = ev_power_w_to_current_a(
                target_w,
                phases=phases,
                voltage_v=voltage_v,
                min_absorb_w=min_absorb_w,
                max_absorb_w=max_absorb_w,
                current_step_a=step_a,
            )

    if target_current_a < 0:
        return {
            'target': 'ev',
            'action': 'skip',
            'reason': 'policy_skip',
            'written': False,
            'policy_source': policy_source,
        }

    if target_current_a > 0:
        enabled_changed = False
        current_changed = False
        if not current_on:
            set_boolean(enabled_entity, True)
            enabled_changed = True
        if target_current_a != current_level:
            set_number(current_entity, target_current_a)
            current_changed = True
        return {
            'target': 'ev',
            'action': 'enable_and_set_current',
            'reason': capability_reason or ('state_changed' if (enabled_changed or current_changed) else 'already_matching'),
            'written': enabled_changed or current_changed,
            'policy_target_w': target_w,
            'target_current_a': target_current_a,
            'enabled_changed': enabled_changed,
            'current_changed': current_changed,
            'policy_source': policy_source,
        }

    if ev_policy_mode == 'restore_min':
        current_changed = False
        if current_level != derived_min_a:
            set_number(current_entity, derived_min_a)
            current_changed = True
        return {
            'target': 'ev',
            'action': 'restore_min_current',
            'reason': capability_reason or 'restore_min',
            'written': current_changed,
            'policy_target_w': target_w,
            'target_current_a': derived_min_a,
            'enabled_changed': False,
            'current_changed': current_changed,
            'policy_source': policy_source,
        }

    enabled_changed = False
    current_changed = False
    if current_on:
        set_boolean(enabled_entity, False)
        enabled_changed = True
    if current_level != derived_min_a:
        set_number(current_entity, derived_min_a)
        current_changed = True
    if ev_policy_mode == 'hard_off':
        return {
            'target': 'ev',
            'action': 'hard_off',
            'reason': capability_reason or 'hard_off',
            'written': enabled_changed or current_changed,
            'policy_target_w': target_w,
            'target_current_a': derived_min_a,
            'enabled_changed': enabled_changed,
            'current_changed': current_changed,
            'policy_source': policy_source,
        }

    if enabled_changed or current_changed:
        return {
            'target': 'ev',
            'action': 'disable_and_restore_min_current',
            'reason': capability_reason or 'target_zero_disable',
            'written': True,
            'policy_target_w': target_w,
            'target_current_a': derived_min_a,
            'enabled_changed': enabled_changed,
            'current_changed': current_changed,
            'policy_source': policy_source,
        }

    return {
        'target': 'ev',
        'action': 'skip',
        'reason': capability_reason or 'already_disabled',
        'written': False,
        'policy_target_w': target_w,
        'current_a': current_level,
        'policy_source': policy_source,
    }


def _write_relay_actuator(policy_ent, actuator_ent, label, device_id=None, entities=None):
    device_policy = _device_policy_by_id(device_id, entities) if device_id else None
    if device_policy is None:
        return {
            'target': label,
            'action': 'skip',
            'reason': 'missing_device_policy',
            'written': False,
            'policy_source': 'missing_device_policy',
        }

    policy_source = 'device_policy'
    device_entities = (entities or {}).get('devices', {}) or {}
    device_runtime = device_entities.get(device_id or '', {})
    if device_runtime.get('enabled'):
        actuator_ent = device_runtime.get('enabled')
    if not actuator_ent:
        if device_id == 'RELAY1':
            actuator_ent = _ent('actuator_relay1', 'switch.relay_1_2', entities)
        elif device_id == 'RELAY2':
            actuator_ent = _ent('actuator_relay2', 'switch.relay_2_2', entities)
    if not actuator_ent:
        return {
            'target': label,
            'action': 'skip',
            'reason': 'missing_actuator_entity',
            'written': False,
            'policy_source': policy_source,
        }
    capability_reason = ''
    if device_id:
        capability_cfg = _capability_device_config_for_id(device_id)
        if capability_cfg is None:
            return {
                'target': label,
                'action': 'skip',
                'reason': 'missing_device_config',
                'written': False,
                'policy_source': policy_source,
            }
        desired_target_w = _device_policy_target_w(device_policy, default=0)
        capability_reason = capability_block_reason(capability_cfg, desired_target_w)
    if str(device_policy.get('mode') or '') == 'skip':
        strategy = -1
    else:
        if capability_reason:
            strategy = 0
        else:
            strategy = 1 if _device_policy_enabled(device_policy) else 0
    is_on = get_bool(actuator_ent)

    if strategy < 0:
        return {
            'target': label,
            'action': 'skip',
            'reason': 'policy_skip',
            'written': False,
            'policy_source': policy_source,
        }

    if strategy == 1 and not is_on:
        set_boolean(actuator_ent, True)
        return {
            'target': label,
            'action': 'turn_on',
            'reason': capability_reason or 'state_changed',
            'written': True,
            'policy_source': policy_source,
        }

    if strategy == 0 and is_on:
        set_boolean(actuator_ent, False)
        return {
            'target': label,
            'action': 'turn_off',
            'reason': capability_reason or 'state_changed',
            'written': True,
            'policy_source': policy_source,
        }

    return {
        'target': label,
        'action': 'skip',
        'reason': capability_reason or 'already_matching',
        'written': False,
        'policy_command': strategy,
        'is_on': is_on,
        'policy_source': policy_source,
    }


def _publish_writer_trace(victron, device_traces, entities=None):
    publish_sensor_fn = globals().get('publish_sensor')
    if publish_sensor_fn is None:
        return

    trace_ent = _ent('actuator_writer_trace', 'sensor.ems_actuator_writer_trace', entities)
    attrs = {
        'writer_policy_contract': 'device_policy_primary',
        'writer_trace_canonical_contract': 'devices',
        'victron': victron,
        'devices': device_traces,
    }
    publish_sensor_fn(trace_ent, 'ACTIVE', attrs)


@time_trigger('period(now, 30s)')
@state_trigger(
    'sensor.ems_policy_decision_trace_pyscript or '
    'input_select.ems_control_profile'
)
def ems_actuator_writers_loop():
    entities = _load_runtime_entities()
    cfg = _load_core_config()
    victron = _write_battery_actuator(entities)
    device_traces = {}
    for device in getattr(cfg, 'devices', {}).values():
        device_id = str(device.device_id)
        kind = str(device.kind)
        if kind == 'EV_CHARGER':
            device_traces[device_id] = _write_ev_actuator(device_id=device_id, entities=entities)
        elif kind == 'RELAY':
            device_traces[device_id] = _write_relay_actuator(
                None,
                '',
                device_id.lower(),
                device_id=device_id,
                entities=entities,
            )
    _publish_writer_trace(victron, device_traces, entities)
    result = {
        'victron': victron,
        'devices': device_traces,
        'writer_trace_canonical_contract': 'devices',
    }
    return result
